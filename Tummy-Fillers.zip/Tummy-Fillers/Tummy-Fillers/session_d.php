<?php
require 'connection.php';
$conn = Connect();

session_start();

$user_check=$_SESSION['login_user3'];

// SQL Query To Fetch Complete Information Of User
$query = "SELECT username,D_ID FROM DELIVERY_BOY WHERE username = '$user_check'";

$ses_sql = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($ses_sql);
$login_session =$row['username'];
$d_ID = $row['D_ID'];
$_SESSION['d_id'] = $d_ID;

// echo $SESSION['d_id'];
?>