<?php
include('session_m.php');

if(!isset($login_session)){
header('Location: managerlogin.php'); // Redirecting To Home Page
}

?>


<!DOCTYPE html>
<html>

<head>
    <title> Manager Login | Tummy Fillers </title>
</head>

<link rel="stylesheet" type="text/css" href="css/myrestaurant.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>

<body>


    <button onclick="topFunction()" id="myBtn" title="Go to top">
        <i class="fa fa-arrow-circle-up"></i>
    </button>

    <script type="text/javascript">
    window.onscroll = function() {
        scrollFunction()
    };

    function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            document.getElementById("myBtn").style.display = "block";
        } else {
            document.getElementById("myBtn").style.display = "none";
        }
    }

    function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }

    function deliver(orderId) {
        console.log(orderId);
        var hostname = window.location.hostname + ":" + window.location.port;
        window.open("http://" + hostname + "/Tummy-Fillers/view_order_details_delivery_boy_dialog.php?o_id=" + orderId,
            "Delivery Boy", "top=250,left=500,height=500, width=500, scrollbars=yes");
    }
    </script>

    <nav class="navbar navbar-inverse navbar-fixed-top navigation-clean-search" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myNavbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand">Tummy Fillers</a>
            </div>

            <div class="collapse navbar-collapse " id="myNavbar">
                <ul class="nav navbar-nav">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="aboutus.php">About</a></li>
                </ul>

                <ul class="nav navbar-nav navbar-right">
                    <li><a href="myrestaurant.php"><i class="fa fa-user"></i>&nbsp; Welcome
                            <?php echo $login_session; ?> </a></li>
                    <li class="active"> <a href="managerlogin.php">MANAGER CONTROL PANEL</a></li>
                    <li><a href="logout_m.php"><i class="fa fa-sign-out"></i>&nbsp; Log Out </a></li>
                </ul>
            </div>

        </div>
    </nav>




    <div class="container-fluid">
        <div class="jumbotron text-center">
            <h1>Hello Manager! </h1>
            <p>Manage all your restaurant from here</p>

        </div>
    </div>

    <div class="container-fluid">
        <div class="container">
            <div class="col">

            </div>
        </div>


        <div class="col-xs-3" style="text-align: center;">

            <div class="list-group">
                <a href="myrestaurant.php" class="list-group-item ">My Restaurant</a>
                <a href="view_food_items.php" class="list-group-item">View Food Items</a>
                <a href="add_food_items.php" class="list-group-item ">Add Food Items</a>
                <a href="edit_food_items.php" class="list-group-item ">Edit Food Items</a>
                <a href="delete_food_items.php" class="list-group-item ">Delete Food Items</a>
                <a href="view_order_details.php" class="list-group-item ">View Order Details</a>
                <a href="view_restaurant.php" class="list-group-item ">View Restaurant</a>
                <a href="Reports.php" class="list-group-item ">Sell Order Reports</a>
                <a href="product_report.php" class="list-group-item active">Product Reports</a>
            </div>
        </div>
<?php $from_dateErr = '';$to_dateErr = ''; $grand=0;?>
        <div class="col-xs-9">
            <div class="form-area" style="padding: 0px 100px 100px 100px;">
                    <br style="clear: both">
                    <h3 style="margin-bottom: 25px; text-align: center; font-size: 30px;"> PRODUCT REPORTS OF SELL GRAPH </h3>

                    <form action="product_report.php" method="post">
                   <div class="row">
                   <div class="col-md-4">
                            <label for="fromdate ">From Date :</label>
                            <span class="error">*</span><br>
                            <input type="date" name="from_date" id="fromdate" class="form-control" autocomplete=off required>
                            <span class="error"><?php echo $from_dateErr;?></span>
                        </div>

                        <div class="col-md-4">
                            <label for="todate ">To Date :</label>
                            <span class="error">*</span><br>
                            <input type="date" name="to_date" id="todate" class="form-control" autocomplete=off required>
                            <span class="error"><?php echo $to_dateErr;?></span>
                        </div>
                        <div class="col-md-4">
                            <!-- <a href="#" class="btn btn-info">Submit</a> -->
                            <!-- <label for="to date ">To Date :</label> -->
                            <span class="error"> </span><br>
                            <input type="submit" class="form-control btn-info" value="Submit">
                        </div>
                   </div>
                   
                    </form>

                    <?php

// Storing Session
$user_check=$_SESSION['login_user1'];

if(isset($_POST['from_date']) && isset($_POST['to_date'])){
    $from_date = $_POST['from_date'];
    $to_date = $_POST['to_date'];

    echo '<br><h4 class="text-info">From Date: ' .$from_date. ' |  To Date: '.$to_date . '</h4>';
$sql ="SELECT SUM(o.quantity) as 'quantity',o.F_ID,f.name 'name' 
        FROM `orders_product_details` o
        INNER JOIN food f
        ON f.F_ID = o.F_ID
        WHERE o.order_date >='$from_date' AND o.order_date <='$to_date'
        GROUP BY F_ID
        ORDER BY quantity desc ";

$result = mysqli_query($conn,$sql);
$chart_data="";
while ($row = mysqli_fetch_assoc($result)) { 

   $productname[]  = $row['name']  ;
   $sales[] = $row['quantity'];
}
}
else{
    echo "<h2 style='text-align:center; margin:105px 0 0 0;' class='text-info'>Plese Select From Date And To Date !</h2>";
}
// $row1 = mysqli_fetch_assoc($result);
?>
<br>
<br>
<canvas  id="chartjs_bar"></canvas>
<script src="//code.jquery.com/jquery-1.9.1.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
<script type="text/javascript">
      var ctx = document.getElementById("chartjs_bar").getContext('2d');
                var myChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels:<?php echo json_encode($productname); ?>,
                        datasets: [{
                            backgroundColor: [
                               "#337ab7",
                                "#333",
                                "#337ab7",
                                "#333",
                                "#337ab7",
                                "#333",
                                "#337ab7",
                                "#333",
                                "#337ab7",
                                "#333",

                                "#337ab7",
                                "#333",
                                "#337ab7",
                                "#333",
                                "#337ab7",
                                "#333",
                                "#337ab7",
                                "#333",
                                "#337ab7",
                                "#333",
                                "#337ab7",
                                "#333",
                                "#337ab7",
                                "#333",
                                "#337ab7",
                                "#333",
                                "#337ab7",
                                "#333",
                                "#337ab7",
                                "#333",
                                "#337ab7",
                                "#333",
                                "#337ab7",
                                "#333",
                                "#337ab7",
                                "#333",
                                "#337ab7",
                                "#333",
                                "#337ab7",
                                "#333",

                            ],
                            data:<?php echo json_encode($sales); ?>,
                        }]
                    },
                    options: {
                           legend: {
                        display: false,
                        position: 'bottom',
 

                    },
                    scales: {
         yAxes: [{
             ticks: {
                 beginAtZero: true,
                 userCallback: function(label, index, labels) {
                     // when the floored value is the same as the value we have a whole number
                     if (Math.floor(label) === label) {
                         return label;
                     }

                 },
             }
         }],
     },
 
                }
                });
    </script>
</body>

</html>