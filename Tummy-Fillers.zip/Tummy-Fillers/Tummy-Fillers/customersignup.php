<?php
  session_start();
?>
<html>
<head>
    <title> Guest Signup | Tummy Fillers </title>
  </head>

  <link rel="stylesheet" type = "text/css" href ="css/managersignup.css">
  <link rel="stylesheet" type = "text/css" href ="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  

  <body>


    <button onclick="topFunction()" id="myBtn" title="Go to top">
    <i class="fa fa-arrow-circle-up"></i>
    </button>
    
  
    <script type="text/javascript">
      window.onscroll = function()
      {
        scrollFunction()
      };

      function scrollFunction(){
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
          document.getElementById("myBtn").style.display = "block";
        } else {
          document.getElementById("myBtn").style.display = "none";
        }
      }

      function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
      }

      function isNumberKey(evt) {
  var charCode = (evt.which) ? evt.which : evt.keyCode
  if (charCode > 31 && (charCode < 48 || charCode > 57))
    return false;
  return true;
}

    function clearForm(){
      console.log('HELOOOOOOOOOOOO');
      console.log(document.getElementById("username").value);
      document.getElementById("username").value="";
    }
      
    </script>

    <nav class="navbar navbar-inverse navbar-fixed-top navigation-clean-search" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myNavbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand">Tummy Fillers</a>
        </div>

        <div class="collapse navbar-collapse " id="myNavbar">
          <ul class="nav navbar-nav">
            <li  ><a href="index.php">Home</a></li>
            <li><a href="aboutus.php">About</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
          </ul>

          <ul class="nav navbar-nav navbar-right">
            <li><a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span><i class="fa fa-sign-in"></i></span> Sign Up <span class="caret"></span> </a>
                <ul class="dropdown-menu">
              <li> <a href="customersignup.php"> User Sign-up</a></li>
              <li> <a href="managersignup.php"> Manager Sign-up</a></li>
    
            </ul>
            </li>

            <li><a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span><i class="fa fa-sign-in"></i></span> Login <span class="caret"></span></a>
              <ul class="dropdown-menu">
              <li> <a href="customerlogin.php"> User Login</a></li>
              <li> <a href="managerlogin.php"> Manager Login</a></li>
              <li> <a href="delivery-boy-login.php"> Delivery Boy Login</a></li>
      
            </ul>
            </li>
          </ul>
        </div>

      </div>
    </nav>

    <div class="container">
    <div class="jumbotron">
     <h1>Hi Guest, <br> Welcome to <span class="edit"> Tummy Fillers </span></h1>
     <br>
   <p>Get started by creating your account</p>
    </div>
    </div>



    <div class="container" style="margin-top: 4%; margin-bottom: 2%;">
      <div class="col-md-5 col-md-offset-4">
      <div class="panel panel-primary">
        <div class="panel-heading"> Create Account </div>
        <div class="panel-body">
          
        <form role="form" action="customersignup.php" method="POST">
         
          <div class="row">
          <div class="form-group col-xs-12">
            <label for="fullname"><span class="text-danger" style="margin-right: 5px;">*</span> Full Name: </label>
            <div class="input-group">
              <input class="form-control" id="fullname" type="text" name="fullname" onkeypress="return ((event.charCode >= 65 && event.charCode <= 90) || (event.charCode >= 97 && event.charCode <= 122) || (event.charCode == 32))" placeholder="Your Full Name" required="" autofocus="">
              <span class="input-group-btn">
                <label class="btn btn-primary"><span aria-hidden="true"><i class="fa fa-user"></i></label>
            </span>
              </span>
            </div>           
          </div>
        </div>

        <div class="row">
          <div class="form-group col-xs-12">
            <label for="username"><span class="text-danger" style="margin-right: 5px;">*</span> Username: </label>
            <div class="input-group">
              <input class="form-control" id="username" type="text" name="username" placeholder="Your Username" required="">
              <span class="input-group-btn">
                <label class="btn btn-primary"><span aria-hidden="true"><i class="fa fa-user"></i></label>
            </span>
              </span>
            </div>           
          </div>
        </div>

        <div class="row">
          <div class="form-group col-xs-12">
            <label for="email"><span class="text-danger" style="margin-right: 5px;">*</span> Email: </label>
            <div class="input-group">
              <input class="form-control" id="email" type="email" name="email" placeholder="Email" required="">
              <span class="input-group-btn">
                <label class="btn btn-primary"><span aria-hidden="true"><i class="fa fa-envelope"></i></label>
            </span>
              </span>
            </div>           
          </div>
        </div>

        <div class="row">
          <div class="form-group col-xs-12">
            <label for="contact"><span class="text-danger" style="margin-right: 5px;">*</span> Contact: </label>
            <div class="input-group">
              <input class="form-control" id="contact" type="tel" maxlength="10"  onkeypress="return isNumberKey(event)" name="contact" maxlength="10" onkeypress="return onlyNumberKey(event)" title="Enter Only 10 Digit number" name="contact" placeholder="Contact" required="">
              <span class="input-group-btn">
                <label class="btn btn-primary"><span aria-hidden="true"><i class="fa fa-phone"></i></label>
            </span>
              
            </div>           
          </div>
        </div>

        <div class="row">
          <div class="form-group col-xs-12">
            <label for="address"><span class="text-danger" style="margin-right: 5px;">*</span> Address: </label>
            <div class="input-group">
              <input class="form-control" id="address" type="text" name="address" placeholder="Address" required="">
              <span class="input-group-btn">
                <label class="btn btn-primary"><span aria-hidden="true"><i class="fa fa-map-marker"></i></label>
            </span>
              </span>
            </div>           
          </div>
        </div>

        <div class="row">
          <div class="form-group col-xs-12">
            <label for="password"><span class="text-danger" style="margin-right: 5px;">*</span> Password: </label>
            <div class="input-group">
              <input class="form-control" id="password" type="password" name="password" pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_=+-]).{8,12}$" placeholder="Password" required="">
              <span class="input-group-btn">
                <label class="btn btn-primary"><span aria-hidden="true"><i class="fa fa-lock"></i></span></label>
            </span>
            </div> 
            
            <div>
                <div>
                        <strong>Strong Password Tips:</strong>
                        <ul>
                                <li>At least 8 to 12 characters</li>
                                <li>At least one number</li>
                                <li>At least one lowercase &amp; one uppercase letter</li>
                                <li>At least one special character</li>
                        </ul>
                </div><!-- END pswd_info -->
        </div>
            
          </div>
        </div>
        <div class="row">
          <div class="form-group col-xs-4">
              <button class="btn btn-primary" type="submit">Submit</button>
          </div>

        </div>
        <label style="margin-left: 5px;">or</label> <br>
       <label style="margin-left: 5px;"><a href="customerlogin.php">Have an account? Login.</a></label>

        </form>

        </div>
        
      </div>
      
    </div>
    </div>



<?php

require 'connection.php';
include 'security.php';
$conn = Connect();

if(isset($_POST['fullname']) && isset($_POST['username']) && isset($_POST['email'])
  && isset($_POST['address']) && isset($_POST['password']) && isset($_POST['contact'])){
  $fullname = $_POST['fullname'];
  $username = $_POST['username'];
  $email = $_POST['email'];
  $contact = $_POST['contact'];
  $address = $_POST['address'];
  $password =$_POST['password'];
  $password1 = encryptIt($password);

  // echo $password1;
  // echo   $username = $_POST['username'];
  $select_query = "select username from customer where username = '$username'";

  // echo $select_query;
  $select_success = mysqli_query($conn, $select_query);

  // echo mysqli_num_rows($select_success );
  if (!mysqli_num_rows($select_success ) > 0  )
  {
    $query = "INSERT into customer(fullname,username,email,contact,address,password) VALUES('" . $fullname . "','" . $username . "','" . $email . "','" . $contact . "','" . $address ."','" . $password1 ."')";
    $success = $conn->query($query);

    if (!$success){
      die("Couldnt enter data: ".$conn->error); 
      // echo '<script>alert("Products already added to cart")</script>';
    }
    else{
      ?>
      <div class="container">
	<div class="jumbotron" style="text-align: center;">
		<h2> <?php echo "Welcome $fullname!" ?> </h2>
		<h1>Your account has been created.</h1>
		<p>Login Now from <a href="customerlogin.php">HERE</a></p>
	</div>
</div>
      <?php
    }

  }else{
  ?>
      <h3 class="text-center alert-danger"><?php echo "User already exist with $username!" ?></h3>
  <?php
  }

echo "<script>clearForm();</script>";
$conn->close();

}
?>


    <footer class="container-fluid bg-4 text-center">
    <br>
    <p> Tummy Filler 2023 | &copy All Rights Reserved </p>
    <br>
    </footer>

    </body>
    
    
</html>