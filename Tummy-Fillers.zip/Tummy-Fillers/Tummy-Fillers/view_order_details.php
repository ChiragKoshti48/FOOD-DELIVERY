<?php
include('session_m.php');

if(!isset($login_session)){
header('Location: managerlogin.php'); 
}

?>
<!DOCTYPE html>
<html>

<head>
    <title> Manager Login | Tummy Fillers </title>
</head>

<link rel="stylesheet" type="text/css" href="css/myrestaurant.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>

<body>


    <button onclick="topFunction()" id="myBtn" title="Go to top">
        <i class="fa fa-arrow-circle-up"></i>
    </button>

    <script type="text/javascript">
    window.onscroll = function() {
        scrollFunction()
    };

    function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            document.getElementById("myBtn").style.display = "block";
        } else {
            document.getElementById("myBtn").style.display = "none";
        }
    }

    function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }

    function deliver(orderId) {
        console.log(orderId);
        var hostname = window.location.hostname + ":" + window.location.port;
        window.open("http://" + hostname + "/Tummy-Fillers/view_order_details_delivery_boy_dialog.php?o_id=" + orderId,
            "Delivery Boy", "top=250,left=500,height=500, width=500, scrollbars=yes");
    }
    </script>

    <nav class="navbar navbar-inverse navbar-fixed-top navigation-clean-search" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myNavbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand">Tummy Fillers</a>
            </div>

            <div class="collapse navbar-collapse " id="myNavbar">
                <ul class="nav navbar-nav">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="aboutus.php">About</a></li>
                </ul>

                <ul class="nav navbar-nav navbar-right">
                    <li><a href="myrestaurant.php"><i class="fa fa-user"></i>&nbsp; Welcome
                            <?php echo $login_session; ?> </a></li>
                    <li class="active"> <a href="managerlogin.php">MANAGER CONTROL PANEL</a></li>
                    <li><a href="logout_m.php"><i class="fa fa-sign-out"></i>&nbsp; Log Out </a></li>
                </ul>
            </div>

        </div>
    </nav>




    <div class="container-fluid">
        <div class="jumbotron text-center">
            <h1>Hello Manager! </h1>
            <p>Manage all your restaurant from here</p>

        </div>
    </div>

    <div class="container-fluid">
        <div class="container">
            <div class="col">

            </div>
        </div>


        <div class="col-xs-3" style="text-align: center;">

            <div class="list-group">
                <a href="myrestaurant.php" class="list-group-item ">My Restaurant</a>
                <a href="view_food_items.php" class="list-group-item">View Food Items</a>
                <a href="add_food_items.php" class="list-group-item ">Add Food Items</a>
                <a href="edit_food_items.php" class="list-group-item ">Edit Food Items</a>
                <a href="delete_food_items.php" class="list-group-item ">Delete Food Items</a>
                <a href="view_order_details.php" class="list-group-item active">View Order Details</a>
                <a href="view_restaurant.php" class="list-group-item ">View Restaurant</a>
                <a href="Reports.php" class="list-group-item ">Sell Order Reports</a>
                <a href="product_report.php" class="list-group-item ">Product Reports</a>
            </div>
        </div>




        <div class="col-xs-9">
            <div class="form-area" style="padding: 0px 100px 100px 100px;">
                <form action="" method="POST">
                    <br style="clear: both">
                    <h3 style="margin-bottom: 25px; text-align: center; font-size: 30px;"> YOUR FOOD ORDER LIST </h3>


                    <?php




// Storing Session
$user_check=$_SESSION['login_user1'];
$sql = "SELECT * FROM orders o WHERE o.R_ID IN (SELECT r.R_ID FROM RESTAURANTS r WHERE r.M_ID='$user_check') 
 ORDER BY order_ID desc" ;
$result = mysqli_query($conn, $sql);


if (mysqli_num_rows($result) > 0)
{

  ?>

                    <table class="table table-striped ">
                        <?PHP
      //OUTPUT DATA OF EACH ROW
      while($row = mysqli_fetch_assoc($result)){
    ?>

                        <tbody>
                          <tr><td></td></tr>
                        <tr>
                                <th> </th>
                                <th> Order ID </th>
                                <th> </th>
                                <th> Order Date </th>
                                <th> Order Time </th>
                                <th>  </th>
                                <th> Customer </th>
                                <th> Status</th>
                                <th> Deliver </th>
                                <th>Deliver Time</th>
                            </tr>
                            <tr>
                                <td><i class="fa fa-circle"></i></td>
                                <td><?php echo $row["order_ID"]; ?></td>
                                <td></td>
                                <td><?php echo $row["order_date"]; ?></td>
                                <td><?php echo $row["order_time"]; ?></td>
                                
                                <td></td>
                                <td><?php echo $row["username"]; ?></td>
                                <td><?php echo $row["status"];?></td>
                                <td>
                                <?php if($row["status"]!='DELIVERED'){
                                  ?>
                                     <button onclick='deliver(<?php echo $row["order_ID"]; ?>)'
                                        class="btn btn-primary">Deliver</button>
                                  <?php
                                      }?>
                                 </td>
                                 <td><?php echo $row["deliver_time"];?></td>
                            </tr>
                            <tr>
                                <td>
                                    <h5
                                        style="padding:5px;background-color:#333;color:white;text-align:center;border-radius:5px;">
                                        Items Details</h5>
                                </td>
                            </tr>


                            <tr style="background-color:#eee;">
                                <th scope="col">#</th>
                                <th></th>
                                <th scope="col">Food Item</th>
                                <th></th>
                                <th scope="col">Quantity</th>
                                <th></th>
                                <th scope="col">Price</th>
                                <th></th>
                                <th></th>
                                <th scope="col">Total</th>

                            </tr>
                            <?php

$grand_total = 0;
$sql1 = "SELECT o.`order_ID`, o.`F_ID`, o.`foodname`, o.`price`, o.`quantity`, o.`order_date`,
o.`order_time`, o.`username`, o.`R_ID`, o.`status`FROM `orders_product_details` as o 
where o.order_id= '$row[order_ID]'";
// echo $user_check;
// echo $sql;
$result1 = mysqli_query($conn, $sql1);
// echo $D_ID;
if (mysqli_num_rows($result1 ) > 0  )
{
$i=0;
while($row1 = mysqli_fetch_assoc($result1))  {
$i++;
?>
                            <tr>
                                <th scope="row"><?php echo $i; ?></th>
                                <td></td>
                                <td><?php echo $row1["foodname"];?></td>
                                <td></td>
                                <td><?php echo $row1["quantity"];?></td>
                                <td></td>
                                <td><?php echo $row1["price"];?></td>
                                <td></td>
                                <td></td>
                                <td><?php $grand_total = $grand_total + $row1["quantity"] * $row1["price"]; echo $row1["quantity"] * $row1["price"];?>
                                </td>

                            </tr>

            </div>
        </div>
        <?php }}else{?>
        <tr>
            <td>No Food Details </td>
        </tr>

        <?php }?>
        <tr>
            <th scope="row"><?php  ?></th>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td class = "alert alert-info"><B><?php echo "Grand Total "?></td>
            <td class = "alert alert-info"> <b><?php echo $grand_total;?></td>

        </tr>
        </tbody>

        <?php } ?>
        </table>
        <br>




        <?php } else { ?>

        <h4>
            <center>0 RESULTS</center>
        </h4>

        <?php } ?>

        </form>


    </div>

    </div>
    </div>
    <br>
    <br>
    <br>
    <br>

    <!-- Delivery Boy Popup Start-->

</body>

</html>